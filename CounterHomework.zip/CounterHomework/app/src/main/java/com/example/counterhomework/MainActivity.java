package com.example.counterhomework;

import androidx.appcompat.app.AppCompatActivity;

import android.app.assist.AssistStructure;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int mCount = 0;
    private TextView mTextView;
    private EditText mEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = (TextView) findViewById(R.id.textView);
        mEditText = findViewById(R.id.editTextTextPersonName);
        if (savedInstanceState != null) {
            boolean isVisible =
                    savedInstanceState.getBoolean("text_visible");
            if (isVisible) {
                mTextView.setVisibility(View.VISIBLE);

            }
        }

    }


    public void countUp(View view) {
        ++mCount;
        if (mTextView != null)
            mTextView.setText(Integer.toString(mCount));
    }
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mTextView.getVisibility() == View.VISIBLE) {
            outState.putBoolean("text_visible", true);
            outState.putString("text",
                    mTextView.getText().toString());
        }
    }
}